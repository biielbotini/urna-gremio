(() => {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const telas = {
    sala: $('#tela-sala'),
    chamada: $('#tela-chamada'),
    voto: $('#tela-voto'),
    fim: $('#tela-fim')
  };

  const st = {
    info: null,
    token: '',
    sala: null, // sala em votação {id, nome, alunos}
    salaSel: null, // id selecionado na tela do mesário
    fase: 'sala', // sala | chamada | voto | fim
    chamada: '', // dígitos digitados na tela de chamada
    aluno: null, // número da chamada liberado para votar
    digitos: '',
    branco: false,
    ocupado: false,
    modal: false,
    timerFim: null
  };

  /* ------------------------------------------------------------ */
  /* Sons (gerados no navegador, sem arquivos)                      */
  /* ------------------------------------------------------------ */
  let ctxAudio = null;
  function audio() {
    try {
      if (!ctxAudio) ctxAudio = new (window.AudioContext || window.webkitAudioContext)();
      if (ctxAudio.state === 'suspended') ctxAudio.resume();
    } catch (e) {
      ctxAudio = null;
    }
    return ctxAudio;
  }
  function tom(freq, dur, inicio, vol) {
    const c = audio();
    if (!c) return;
    const t0 = c.currentTime + (inicio || 0);
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = 'square';
    osc.frequency.value = freq;
    g.gain.setValueAtTime(vol || 0.08, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }
  function bip(tipo) {
    if (tipo === 'tecla') tom(1100, 0.06);
    else if (tipo === 'erro') tom(260, 0.28, 0, 0.1);
    else if (tipo === 'fim') {
      tom(900, 0.14, 0, 0.1);
      tom(900, 0.14, 0.2, 0.1);
      tom(700, 1.1, 0.42, 0.1);
    }
  }

  /* ------------------------------------------------------------ */
  /* Comunicação com o servidor                                     */
  /* ------------------------------------------------------------ */
  async function chamarApi(metodo, url, corpo) {
    let resp;
    try {
      resp = await fetch(url, {
        method: metodo,
        headers: corpo ? { 'Content-Type': 'application/json' } : undefined,
        body: corpo ? JSON.stringify(corpo) : undefined
      });
    } catch (e) {
      const err = new Error('Sem conexão com o servidor da urna.');
      err.rede = true;
      throw err;
    }
    let dados = {};
    try {
      dados = await resp.json();
    } catch (e) {
      /* resposta sem corpo */
    }
    if (!resp.ok) {
      const err = new Error(dados.erro || 'Erro inesperado (' + resp.status + ').');
      err.status = resp.status;
      throw err;
    }
    return dados;
  }

  /* ------------------------------------------------------------ */
  /* Troca de telas                                                 */
  /* ------------------------------------------------------------ */
  function mostrar(fase) {
    st.fase = fase;
    Object.keys(telas).forEach((k) => telas[k].classList.toggle('oculto', k !== fase));
    document.body.classList.toggle('modo-mesario', fase === 'sala');
  }

  function desenharCaixas(container, qtd, texto, comCursor) {
    container.innerHTML = '';
    for (let i = 0; i < qtd; i++) {
      const b = document.createElement('span');
      b.className = 'caixa' + (comCursor && i === texto.length ? ' atual' : '');
      b.textContent = texto[i] || '';
      container.appendChild(b);
    }
  }

  /* ------------------------------------------------------------ */
  /* 1. Seleção de sala (mesário)                                   */
  /* ------------------------------------------------------------ */
  function msgSala(texto, ok) {
    const e = $('#msg-sala');
    e.textContent = texto || '';
    e.classList.toggle('ok', !!ok);
  }

  function desenharSalas() {
    const info = st.info;
    $('#titulo-eleicao').textContent = info.titulo;
    $('#linha-pin').classList.toggle('oculto', !info.pinObrigatorio);
    const lista = $('#lista-salas');
    lista.innerHTML = '';
    if (!info.salas.length) {
      lista.innerHTML = '<p>Nenhuma sala cadastrada. Cadastre as salas no painel de administração.</p>';
    }
    info.salas.forEach((s) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'sala-btn' + (st.salaSel === s.id ? ' sel' : '');
      b.dataset.id = s.id;
      b.disabled = s.status === 'encerrada';
      const nome = document.createElement('span');
      nome.textContent = s.nome;
      const sub = document.createElement('small');
      sub.textContent = s.status === 'encerrada' ? 'Votação encerrada' : s.status === 'aberta' ? 'Em andamento' : 'Aguardando';
      b.append(nome, sub);
      lista.appendChild(b);
    });
    $('#btn-iniciar').disabled = !st.salaSel;
  }

  async function carregarInfo() {
    const url = '/api/urna/info' + (st.token ? '?token=' + encodeURIComponent(st.token) : '');
    st.info = await chamarApi('GET', url);
    return st.info;
  }

  function irParaSelecaoDeSala(mensagem, ok) {
    st.token = '';
    st.sala = null;
    st.salaSel = null;
    sessionStorage.removeItem('urna_token');
    clearTimeout(st.timerFim);
    mostrar('sala');
    msgSala(mensagem || '', ok);
    carregarInfo()
      .then(desenharSalas)
      .catch((e) => msgSala(e.message));
  }

  $('#lista-salas').addEventListener('click', (e) => {
    const b = e.target.closest('.sala-btn');
    if (!b || b.disabled) return;
    st.salaSel = b.dataset.id;
    msgSala('');
    desenharSalas();
  });

  async function iniciarVotacao() {
    if (!st.salaSel || st.ocupado) return;
    audio();
    st.ocupado = true;
    try {
      const r = await chamarApi('POST', '/api/urna/abrir', {
        salaId: st.salaSel,
        pin: $('#pin').value
      });
      st.token = r.token;
      st.sala = r.sala;
      sessionStorage.setItem('urna_token', r.token);
      $('#pin').value = '';
      try {
        if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen().catch(() => {});
        }
      } catch (e) {
        /* tela cheia é opcional */
      }
      entrarNaChamada();
    } catch (e) {
      msgSala(e.message);
      if (e.status === 409) {
        carregarInfo().then(desenharSalas).catch(() => {});
      }
    } finally {
      st.ocupado = false;
    }
  }
  $('#btn-iniciar').addEventListener('click', iniciarVotacao);
  $('#pin').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') iniciarVotacao();
  });

  /* ------------------------------------------------------------ */
  /* 2. Número da chamada                                           */
  /* ------------------------------------------------------------ */
  function msgChamada(texto) {
    $('#msg-chamada').textContent = texto || '';
  }

  function entrarNaChamada() {
    clearTimeout(st.timerFim);
    st.chamada = '';
    st.aluno = null;
    st.digitos = '';
    st.branco = false;
    mostrar('chamada');
    $('#chamada-sala').textContent = 'Sala: ' + st.sala.nome;
    msgChamada('');
    renderChamada();
  }

  function renderChamada() {
    desenharCaixas($('#caixas-chamada'), 2, st.chamada, st.chamada.length < 2);
  }

  async function confirmarChamada() {
    const n = parseInt(st.chamada, 10);
    if (!st.chamada || !(n >= 1)) {
      msgChamada('Digite o número da chamada.');
      return bip('erro');
    }
    st.ocupado = true;
    try {
      await chamarApi('POST', '/api/urna/chamada', { token: st.token, chamada: n });
      st.aluno = n;
      st.digitos = '';
      st.branco = false;
      mostrar('voto');
      renderVoto();
      bip('tecla');
    } catch (e) {
      bip('erro');
      if (e.status === 401 || (e.status === 409 && /encerrada/.test(e.message))) {
        irParaSelecaoDeSala(e.message);
      } else {
        msgChamada(e.message);
        st.chamada = '';
        renderChamada();
      }
    } finally {
      st.ocupado = false;
    }
  }

  /* ------------------------------------------------------------ */
  /* 3. Votação                                                     */
  /* ------------------------------------------------------------ */
  function candidatoAtual() {
    if (st.digitos.length !== st.info.digitos) return null;
    return st.info.candidatos.find((c) => c.numero === st.digitos) || null;
  }

  const ehSimNao = () => !!st.info && st.info.modo === 'simnao';

  function renderVoto() {
    const simnao = ehSimNao();
    const n = st.info.digitos;
    const completo = st.digitos.length === n;
    const chapa = simnao ? st.info.candidatos[0] || null : null;
    const cand = simnao ? chapa : candidatoAtual();
    const respostaValida = simnao && completo && (st.digitos === '1' || st.digitos === '2');

    $('#voto-cargo').textContent = st.info.cargo;
    $('#bloco-numero').classList.toggle('oculto', st.branco);
    $('#rot-numero').textContent = simnao ? 'Digite:' : 'Número:';
    $('#bloco-opcoes').classList.toggle('oculto', !simnao);
    $('#bloco-branco').classList.toggle('oculto', !st.branco);
    desenharCaixas($('#caixas-voto'), n, st.digitos, !completo);

    /* Modo Sim/Não: chapa e pergunta ficam sempre na tela */
    $('#bloco-chapa').classList.toggle('oculto', !simnao);
    if (simnao) {
      $('#v-chapa-nome').textContent = chapa ? chapa.nome : '';
      $('#v-chapa-desc').textContent = chapa ? chapa.partido : '';
      $('#linha-integrantes').classList.toggle('oculto', !(chapa && chapa.partido));
      $('#v-pergunta').textContent = st.info.pergunta || '';
    }
    $('#bloco-resposta').classList.toggle('oculto', !respostaValida || st.branco);
    if (respostaValida) $('#v-resposta').textContent = st.digitos === '1' ? 'SIM' : 'NÃO';

    $('#bloco-info').classList.toggle('oculto', simnao || !cand);
    const nulo = !st.branco && completo && (simnao ? !respostaValida : !cand);
    $('#bloco-nulo').classList.toggle('oculto', !nulo);
    $('#foto-box').classList.toggle('oculto', !cand);

    if (cand) {
      $('#v-nome').textContent = cand.nome;
      $('#v-partido').textContent = cand.partido || '—';
      $('#v-legenda').textContent = simnao ? 'Chapa' : st.info.cargo;
      const img = $('#v-foto');
      const fonte = cand.foto || (simnao ? '/logo.png' : '');
      if (fonte) {
        img.src = fonte;
        img.classList.toggle('logo-fallback', !cand.foto);
        img.classList.remove('oculto');
        $('#v-sem-foto').classList.add('oculto');
      } else {
        img.removeAttribute('src');
        img.classList.add('oculto');
        $('#v-sem-foto').classList.remove('oculto');
      }
    }

    let rodape = '<p>Aperte a tecla:</p>';
    if (simnao) rodape += '<p><b>1</b> para votar <b>SIM</b> &nbsp;•&nbsp; <b>2</b> para votar <b>NÃO</b></p>';
    if (!st.branco && st.digitos.length === 0) rodape += '<p><b>BRANCO</b> para votar em <b>BRANCO</b></p>';
    rodape += '<p><b>VERDE</b> para <b>CONFIRMAR</b> este voto</p>';
    rodape += '<p><b>LARANJA</b> para <b>REINICIAR</b> este voto</p>';
    $('#rodape-texto').innerHTML = rodape;
  }

  async function confirmarVoto() {
    let voto;
    if (st.branco) voto = 'branco';
    else if (st.digitos.length === st.info.digitos) {
      if (ehSimNao()) voto = st.digitos === '1' || st.digitos === '2' ? st.digitos : 'nulo';
      else voto = candidatoAtual() ? st.digitos : 'nulo';
    } else return bip('erro');

    st.ocupado = true;
    try {
      await chamarApi('POST', '/api/urna/votar', { token: st.token, chamada: st.aluno, voto });
      mostrar('fim');
      bip('fim');
      st.timerFim = setTimeout(entrarNaChamada, 3800);
    } catch (e) {
      bip('erro');
      if (e.status === 401 || (e.status === 409 && /encerrada/.test(e.message))) {
        irParaSelecaoDeSala(e.message);
      } else {
        entrarNaChamada();
        msgChamada(e.message);
      }
    } finally {
      st.ocupado = false;
    }
  }

  /* ------------------------------------------------------------ */
  /* Teclas (teclado do computador e teclado na tela)               */
  /* ------------------------------------------------------------ */
  function tecla(t) {
    if (st.ocupado || st.modal) return;

    if (st.fase === 'chamada') {
      if (/^\d$/.test(t)) {
        msgChamada('');
        if (st.chamada.length < 2) {
          st.chamada += t;
          bip('tecla');
        } else bip('erro');
        renderChamada();
      } else if (t === 'corrige') {
        st.chamada = '';
        msgChamada('');
        bip('tecla');
        renderChamada();
      } else if (t === 'confirma') {
        confirmarChamada();
      } else {
        bip('erro');
      }
      return;
    }

    if (st.fase === 'voto') {
      if (/^\d$/.test(t)) {
        if (st.branco || st.digitos.length >= st.info.digitos) return bip('erro');
        st.digitos += t;
        bip('tecla');
        renderVoto();
      } else if (t === 'corrige') {
        st.digitos = '';
        st.branco = false;
        bip('tecla');
        renderVoto();
      } else if (t === 'branco') {
        if (st.digitos.length > 0) return bip('erro');
        st.branco = true;
        bip('tecla');
        renderVoto();
      } else if (t === 'confirma') {
        confirmarVoto();
      }
    }
  }

  document.addEventListener(
    'keydown',
    (e) => {
      const k = e.key || '';

      /* Atalho do mesário para encerrar a sala (não é mostrado na tela). */
      if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && k.toLowerCase() === 'e') {
        e.preventDefault();
        if (st.fase === 'chamada' && !st.modal && !st.ocupado) abrirModal();
        return;
      }

      if (st.modal) {
        if (k === 'Enter') {
          e.preventDefault();
          confirmarEncerramento();
        } else if (k === 'Escape') {
          e.preventDefault();
          fecharModal();
        }
        return;
      }

      if (st.fase !== 'chamada' && st.fase !== 'voto') return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;

      if (/^[0-9]$/.test(k)) {
        e.preventDefault();
        tecla(k);
      } else if (k === 'Enter') {
        e.preventDefault();
        if (!e.repeat) tecla('confirma');
      } else if (k === 'Backspace' || k === 'Delete') {
        e.preventDefault();
        tecla('corrige');
      } else if (k === 'b' || k === 'B') {
        e.preventDefault();
        tecla('branco');
      } else if ((k === 's' || k === 'S') && st.fase === 'voto' && ehSimNao()) {
        e.preventDefault();
        tecla('1');
      } else if ((k === 'n' || k === 'N') && st.fase === 'voto' && ehSimNao()) {
        e.preventDefault();
        tecla('2');
      }
    },
    true
  );

  $('#teclado').addEventListener('mousedown', (e) => e.preventDefault());
  $('#teclado').addEventListener('click', (e) => {
    const b = e.target.closest('.tecla');
    if (b) tecla(b.dataset.tecla);
  });

  document.addEventListener('contextmenu', (e) => {
    if (st.fase !== 'sala') e.preventDefault();
  });

  /* ------------------------------------------------------------ */
  /* Encerramento da sala (Ctrl + E)                                */
  /* ------------------------------------------------------------ */
  function abrirModal() {
    st.modal = true;
    $('#modal-texto').textContent = 'Deseja encerrar a votação da sala ' + st.sala.nome + '? Esta ação é definitiva.';
    $('#modal').classList.remove('oculto');
  }
  function fecharModal() {
    st.modal = false;
    $('#modal').classList.add('oculto');
  }
  async function confirmarEncerramento() {
    if (st.ocupado) return;
    st.ocupado = true;
    try {
      const r = await chamarApi('POST', '/api/urna/encerrar', { token: st.token });
      fecharModal();
      irParaSelecaoDeSala('Votação da sala ' + r.nome + ' encerrada. Total de alunos que votaram: ' + r.votaram + '.', true);
    } catch (e) {
      fecharModal();
      if (e.status === 401 || e.status === 409) irParaSelecaoDeSala(e.message);
      else msgChamada(e.message);
    } finally {
      st.ocupado = false;
    }
  }
  $('#modal-cancelar').addEventListener('click', fecharModal);
  $('#modal-confirmar').addEventListener('click', confirmarEncerramento);

  /* ------------------------------------------------------------ */
  /* Início                                                         */
  /* ------------------------------------------------------------ */
  async function iniciar() {
    st.token = sessionStorage.getItem('urna_token') || '';
    try {
      const info = await carregarInfo();
      if (info.sessao) {
        st.sala = info.sessao;
        entrarNaChamada();
      } else {
        st.token = '';
        sessionStorage.removeItem('urna_token');
        mostrar('sala');
        if (!info.candidatos.length) msgSala('Nenhum candidato cadastrado. Cadastre os candidatos no painel de administração.');
        desenharSalas();
      }
    } catch (e) {
      mostrar('sala');
      msgSala(e.message + ' Tentando novamente...');
      setTimeout(iniciar, 3000);
    }
  }
  iniciar();
})();
