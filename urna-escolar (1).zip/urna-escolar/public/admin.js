(() => {
  'use strict';

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) =>
    String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let token = sessionStorage.getItem('admin_token') || '';
  let dados = null;
  let editandoCand = null;
  let editandoSala = null;
  let foto = { mudou: false, valor: '' };
  let ultimoResultado = null;
  let timerAuto = null;

  const CORES = ['#2563eb', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#14b8a6'];
  const COR_BRANCO = '#9ca3af';
  const COR_NULO = '#4b5563';

  /* ------------------------------------------------------------ */
  /* Utilidades                                                     */
  /* ------------------------------------------------------------ */
  function aviso(texto, tipo) {
    const t = $('#toast');
    t.textContent = texto;
    t.className = 'toast visivel' + (tipo === 'erro' ? ' erro' : '');
    clearTimeout(aviso.t);
    aviso.t = setTimeout(() => (t.className = 'toast'), 3200);
  }

  async function api(metodo, url, corpo, comoTexto) {
    const headers = {};
    if (corpo) headers['Content-Type'] = 'application/json';
    if (token) headers['Authorization'] = 'Bearer ' + token;
    let resp;
    try {
      resp = await fetch(url, { method: metodo, headers, body: corpo ? JSON.stringify(corpo) : undefined });
    } catch (e) {
      throw new Error('Sem conexão com o servidor.');
    }
    if (resp.status === 401 && url !== '/api/admin/login' && url !== '/api/admin/senha') {
      sair(true);
      throw new Error('Sessão expirada. Entre novamente.');
    }
    if (!resp.ok) {
      let msg = 'Erro inesperado (' + resp.status + ').';
      try {
        msg = (await resp.json()).erro || msg;
      } catch (e) {
        /* sem corpo */
      }
      throw new Error(msg);
    }
    return comoTexto ? resp.text() : resp.json();
  }

  const pct = (n, total) => (total ? ((n * 100) / total).toFixed(1).replace('.', ',') + '%' : '0,0%');
  const rotuloStatus = { pendente: 'Aguardando', aberta: 'Em andamento', encerrada: 'Encerrada' };

  /* ------------------------------------------------------------ */
  /* Login / sessão                                                 */
  /* ------------------------------------------------------------ */
  function sair(expirou) {
    token = '';
    sessionStorage.removeItem('admin_token');
    clearInterval(timerAuto);
    $('#app').classList.add('oculto');
    $('#login').classList.remove('oculto');
    $('#login-msg').textContent = expirou ? 'Sessão expirada. Entre novamente.' : '';
    $('#login-senha').value = '';
    $('#login-senha').focus();
  }

  $('#form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#login-msg').textContent = '';
    try {
      const r = await api('POST', '/api/admin/login', { senha: $('#login-senha').value });
      token = r.token;
      sessionStorage.setItem('admin_token', token);
      await entrar();
    } catch (err) {
      $('#login-msg').textContent = err.message;
    }
  });
  $('#btn-sair').addEventListener('click', () => sair(false));

  async function entrar() {
    await recarregar();
    $('#login').classList.add('oculto');
    $('#app').classList.remove('oculto');
    mostrarAba('candidatos');
  }

  async function recarregar() {
    dados = await api('GET', '/api/admin/dados');
    $('#topo-titulo').textContent = dados.config.titulo;
    document.title = 'Administração — ' + dados.config.titulo;
    $('#aviso-senha').classList.toggle('oculto', !dados.config.senhaPadrao);
    renderCandidatos();
    renderSalas();
    renderConfig();
    preencherSelectSalas();
  }

  /* ------------------------------------------------------------ */
  /* Abas                                                           */
  /* ------------------------------------------------------------ */
  function mostrarAba(nome) {
    $$('#abas button').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === nome));
    $$('.aba').forEach((s) => s.classList.toggle('oculto', s.id !== 'aba-' + nome));
    clearInterval(timerAuto);
    if (nome === 'resultados') {
      carregarResultados();
      if ($('#res-auto').checked) timerAuto = setInterval(carregarResultados, 10000);
    } else if (nome === 'frequencia') {
      carregarFrequencia();
      if ($('#fq-auto').checked) timerAuto = setInterval(carregarFrequencia, 10000);
    }
  }
  $('#abas').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-aba]');
    if (b) {
      recarregar().catch(() => {});
      mostrarAba(b.dataset.aba);
    }
  });

  /* ------------------------------------------------------------ */
  /* Candidatos                                                     */
  /* ------------------------------------------------------------ */
  function mostrarFotoPrev(src) {
    const p = $('#c-prev');
    p.innerHTML = src ? '<img alt="" src="' + esc(src) + '">' : '<span>sem foto</span>';
    $('#c-foto-remover').classList.toggle('oculto', !src);
  }

  const ehSimNao = () => !!dados && dados.config.modo === 'simnao';

  function renderCandidatos() {
    const simnao = ehSimNao();
    const d = dados.config.digitos;
    const bloqueado = dados.temVotos;

    // textos e campos conforme o tipo de votação
    $('#lbl-c-nome').textContent = simnao ? 'Nome da chapa' : 'Nome do candidato';
    $('#lbl-c-partido').textContent = simnao ? 'Integrantes / descrição' : 'Chapa / Turma';
    $('#lbl-c-numero-wrap').classList.toggle('oculto', simnao);
    $('#c-numero').required = !simnao;
    $('#c-dica-digitos').textContent = '(' + d + ' dígito' + (d > 1 ? 's' : '') + ')';
    $('#c-numero').maxLength = d;
    $('#cand-simnao-info').classList.toggle('oculto', !simnao);
    $('#cand-titulo-form').textContent = editandoCand ? (simnao ? 'Editar chapa' : 'Editar candidato') : simnao ? 'Nova chapa' : 'Novo candidato';
    $('#cand-lista-titulo').textContent = simnao ? 'Chapa cadastrada' : 'Candidatos cadastrados';
    $('#cand-lista-sub').textContent = simnao
      ? 'O eleitor responde SIM ou NÃO a esta chapa. Branco e nulo são registrados automaticamente.'
      : 'Votos em branco e nulos são registrados automaticamente.';
    $('#abas button[data-aba="candidatos"]').textContent = simnao ? 'Chapa' : 'Candidatos';

    $('#cand-bloqueio').classList.toggle('oculto', !bloqueado);
    $('#c-numero').disabled = simnao || (bloqueado && !!editandoCand);
    const jaTemChapa = simnao && dados.candidatos.length >= 1;
    $('#c-salvar').disabled = !editandoCand && (bloqueado || jaTemChapa);

    const lista = $('#lista-candidatos');
    if (!dados.candidatos.length) {
      lista.innerHTML = '<p class="vazio">' + (simnao ? 'Nenhuma chapa cadastrada ainda.' : 'Nenhum candidato cadastrado ainda.') + '</p>';
      return;
    }
    lista.innerHTML = dados.candidatos
      .map(
        (c) => `
      <article class="cand">
        <div class="cand-foto">${c.foto ? '<img alt="" src="' + esc(c.foto) + '">' : 'sem foto'}</div>
        <div class="cand-info">
          <div class="cand-num"${simnao ? ' style="font-size:15px;letter-spacing:.5px"' : ''}>${simnao ? 'CHAPA' : esc(c.numero)}</div>
          <strong>${esc(c.nome)}</strong>
          <span>${esc(c.partido)}</span>
        </div>
        <div class="cand-acoes">
          <button type="button" class="btn peq" data-acao="editar" data-id="${esc(c.id)}">Editar</button>
          <button type="button" class="btn peq perigo" data-acao="excluir" data-id="${esc(c.id)}" ${bloqueado ? 'disabled' : ''}>Excluir</button>
        </div>
      </article>`
      )
      .join('');
  }

  function limparFormCand() {
    editandoCand = null;
    foto = { mudou: false, valor: '' };
    $('#form-cand').reset();
    $('#cand-titulo-form').textContent = 'Novo candidato';
    $('#c-salvar').textContent = 'Cadastrar';
    $('#c-cancelar').classList.add('oculto');
    $('#cand-msg').textContent = '';
    mostrarFotoPrev('');
    renderCandidatos();
  }

  $('#lista-candidatos').addEventListener('click', async (e) => {
    const b = e.target.closest('button[data-acao]');
    if (!b) return;
    const cand = dados.candidatos.find((c) => c.id === b.dataset.id);
    if (!cand) return;
    if (b.dataset.acao === 'editar') {
      editandoCand = cand.id;
      foto = { mudou: false, valor: cand.foto || '' };
      $('#c-nome').value = cand.nome;
      $('#c-numero').value = cand.numero;
      $('#c-partido').value = cand.partido;
      $('#cand-titulo-form').textContent = 'Editar candidato';
      $('#c-salvar').textContent = 'Salvar alterações';
      $('#c-cancelar').classList.remove('oculto');
      $('#cand-msg').textContent = '';
      mostrarFotoPrev(cand.foto);
      renderCandidatos();
      $('#c-nome').focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (b.dataset.acao === 'excluir') {
      if (!confirm('Excluir o candidato ' + cand.nome + ' (' + cand.numero + ')?')) return;
      try {
        await api('DELETE', '/api/admin/candidatos/' + cand.id);
        aviso('Candidato excluído.');
        if (editandoCand === cand.id) limparFormCand();
        await recarregar();
      } catch (err) {
        aviso(err.message, 'erro');
      }
    }
  });

  $('#c-cancelar').addEventListener('click', limparFormCand);

  $('#c-foto').addEventListener('change', (e) => {
    const arq = e.target.files[0];
    e.target.value = '';
    if (!arq) return;
    const leitor = new FileReader();
    leitor.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 360;
        const esc2 = Math.min(1, max / Math.max(img.width, img.height));
        const cv = document.createElement('canvas');
        cv.width = Math.round(img.width * esc2);
        cv.height = Math.round(img.height * esc2);
        const cx = cv.getContext('2d');
        cx.fillStyle = '#fff';
        cx.fillRect(0, 0, cv.width, cv.height);
        cx.drawImage(img, 0, 0, cv.width, cv.height);
        foto = { mudou: true, valor: cv.toDataURL('image/jpeg', 0.85) };
        mostrarFotoPrev(foto.valor);
      };
      img.onerror = () => aviso('Não foi possível ler essa imagem.', 'erro');
      img.src = leitor.result;
    };
    leitor.readAsDataURL(arq);
  });

  $('#c-foto-remover').addEventListener('click', () => {
    foto = { mudou: true, valor: '' };
    mostrarFotoPrev('');
  });

  $('#form-cand').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#cand-msg').textContent = '';
    const corpo = {
      nome: $('#c-nome').value,
      numero: $('#c-numero').value,
      partido: $('#c-partido').value
    };
    if (foto.mudou || !editandoCand) corpo.foto = foto.valor;
    try {
      if (editandoCand) await api('PUT', '/api/admin/candidatos/' + editandoCand, corpo);
      else await api('POST', '/api/admin/candidatos', corpo);
      aviso(editandoCand ? 'Candidato atualizado.' : 'Candidato cadastrado.');
      editandoCand = null;
      await recarregar();
      limparFormCand();
      $('#c-nome').focus();
    } catch (err) {
      $('#cand-msg').textContent = err.message;
    }
  });

  /* ------------------------------------------------------------ */
  /* Salas                                                          */
  /* ------------------------------------------------------------ */
  function renderSalas() {
    const corpo = $('#tab-salas tbody');
    if (!dados.salas.length) {
      corpo.innerHTML = '<tr><td colspan="5" class="vazio">Nenhuma sala cadastrada ainda.</td></tr>';
      return;
    }
    corpo.innerHTML = dados.salas
      .map(
        (s) => `
      <tr>
        <td><b>${esc(s.nome)}</b></td>
        <td>${s.alunos}</td>
        <td>${s.votaram}</td>
        <td><span class="selo ${esc(s.status)}">${esc(rotuloStatus[s.status] || s.status)}</span></td>
        <td class="nao-imprimir"><div class="acoes-linha">
          <button type="button" class="btn peq" data-acao="editar" data-id="${esc(s.id)}">Editar</button>
          <button type="button" class="btn peq" data-acao="presenca" data-id="${esc(s.id)}">Quem votou</button>
          ${s.status === 'encerrada' ? `<button type="button" class="btn peq" data-acao="reabrir" data-id="${esc(s.id)}">Reabrir</button>` : `<button type="button" class="btn peq" data-acao="encerrar" data-id="${esc(s.id)}">Encerrar</button>`}
          <button type="button" class="btn peq perigo" data-acao="excluir" data-id="${esc(s.id)}" ${s.votaram ? 'disabled' : ''}>Excluir</button>
        </div></td>
      </tr>`
      )
      .join('');
  }

  function limparFormSala() {
    editandoSala = null;
    $('#form-sala').reset();
    $('#s-alunos').value = 50;
    $('#sala-titulo-form').textContent = 'Nova sala';
    $('#s-salvar').textContent = 'Cadastrar';
    $('#s-cancelar').classList.add('oculto');
    $('#bloco-varias').classList.remove('oculto');
    $('#sala-msg').textContent = '';
  }

  $('#s-cancelar').addEventListener('click', limparFormSala);

  $('#tab-salas').addEventListener('click', async (e) => {
    const b = e.target.closest('button[data-acao]');
    if (!b) return;
    const sala = dados.salas.find((s) => s.id === b.dataset.id);
    if (!sala) return;
    const acao = b.dataset.acao;
    try {
      if (acao === 'presenca') {
        $('#fq-sala').value = sala.id;
        mostrarAba('frequencia');
        return;
      }
      if (acao === 'editar') {
        editandoSala = sala.id;
        $('#s-nome').value = sala.nome;
        $('#s-alunos').value = sala.alunos;
        $('#sala-titulo-form').textContent = 'Editar sala';
        $('#s-salvar').textContent = 'Salvar alterações';
        $('#s-cancelar').classList.remove('oculto');
        $('#bloco-varias').classList.add('oculto');
        $('#sala-msg').textContent = '';
        $('#s-nome').focus();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      if (acao === 'excluir') {
        if (!confirm('Excluir a sala ' + sala.nome + '?')) return;
        await api('DELETE', '/api/admin/salas/' + sala.id);
        aviso('Sala excluída.');
      } else if (acao === 'encerrar') {
        if (!confirm('Encerrar a votação da sala ' + sala.nome + '? Ninguém mais poderá votar nela.')) return;
        await api('POST', '/api/admin/salas/' + sala.id + '/encerrar');
        aviso('Sala encerrada.');
      } else if (acao === 'reabrir') {
        if (!confirm('Reabrir a sala ' + sala.nome + '? Quem já votou continuará bloqueado.')) return;
        await api('POST', '/api/admin/salas/' + sala.id + '/reabrir');
        aviso('Sala reaberta.');
      }
      await recarregar();
    } catch (err) {
      aviso(err.message, 'erro');
    }
  });

  $('#form-sala').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#sala-msg').textContent = '';
    try {
      if (editandoSala) {
        await api('PUT', '/api/admin/salas/' + editandoSala, {
          nome: $('#s-nome').value,
          alunos: $('#s-alunos').value
        });
        aviso('Sala atualizada.');
      } else {
        const varias = $('#s-varias')
          .value.split('\n')
          .map((x) => x.trim())
          .filter(Boolean);
        const nomes = varias.length ? varias : [$('#s-nome').value];
        const r = await api('POST', '/api/admin/salas', { nomes, alunos: $('#s-alunos').value });
        aviso(r.criadas + (r.criadas > 1 ? ' salas cadastradas.' : ' sala cadastrada.'));
      }
      await recarregar();
      limparFormSala();
    } catch (err) {
      $('#sala-msg').textContent = err.message;
    }
  });

  /* ------------------------------------------------------------ */
  /* Resultados                                                     */
  /* ------------------------------------------------------------ */
  function preencherSelectSalas() {
    ['#res-sala', '#fq-sala'].forEach((id) => {
      const sel = $(id);
      const atual = sel.value || 'all';
      sel.innerHTML = '<option value="all">Todas as salas</option>' + dados.salas.map((s) => `<option value="${esc(s.id)}">${esc(s.nome)}</option>`).join('');
      sel.value = dados.salas.some((s) => s.id === atual) ? atual : 'all';
    });
  }

  async function carregarResultados() {
    try {
      const r = await api('GET', '/api/admin/resultados?sala=' + encodeURIComponent($('#res-sala').value || 'all'));
      ultimoResultado = r;
      renderResultados(r);
    } catch (err) {
      $('#res-conteudo').innerHTML = '<p class="msg erro">' + esc(err.message) + '</p>';
    }
  }

  function itensGrafico(r) {
    let itens;
    if (r.modo === 'simnao') {
      itens = [
        { rotulo: 'SIM', valor: r.sim, cor: CORES[0] },
        { rotulo: 'NÃO', valor: r.nao, cor: CORES[1] }
      ];
    } else {
      itens = r.candidatos.map((c, i) => ({
        rotulo: c.nome + ' (' + c.numero + ')',
        valor: c.votos,
        cor: CORES[i % CORES.length]
      }));
    }
    itens.push({ rotulo: 'Branco', valor: r.branco, cor: COR_BRANCO });
    itens.push({ rotulo: 'Nulo', valor: r.nulo, cor: COR_NULO });
    return itens;
  }

  function cortar(txt, n) {
    return txt.length > n ? txt.slice(0, n - 1) + '…' : txt;
  }

  function graficoBarras(itens, total) {
    const largRot = 190;
    const largBarra = 220;
    const alt = 40;
    const topo = 8;
    const H = topo + itens.length * alt + 8;
    const max = Math.max(1, ...itens.map((i) => i.valor));
    let s = `<svg viewBox="0 0 600 ${H}" role="img" aria-label="Gráfico de barras dos votos">`;
    itens.forEach((it, i) => {
      const y = topo + i * alt;
      const w = Math.round((it.valor / max) * largBarra);
      s += `<text x="${largRot - 10}" y="${y + 23}" text-anchor="end" font-size="14" fill="#1b1f27">${esc(cortar(it.rotulo, 24))}</text>`;
      s += `<rect x="${largRot}" y="${y + 4}" width="${largBarra}" height="28" rx="5" fill="#eef1f7"/>`;
      if (w > 0) s += `<rect x="${largRot}" y="${y + 4}" width="${w}" height="28" rx="5" fill="${it.cor}"/>`;
      s += `<text x="${largRot + largBarra + 10}" y="${y + 23}" font-size="14" font-weight="700" fill="#1b1f27">${it.valor} (${pct(it.valor, total)})</text>`;
    });
    return s + '</svg>';
  }

  function graficoPizza(itens, total) {
    const fatias = itens.filter((i) => i.valor > 0);
    const cx = 120;
    const cy = 120;
    const raio = 112;
    let svg = `<svg viewBox="0 0 240 240" role="img" aria-label="Gráfico de pizza dos votos">`;
    if (!total) {
      svg += `<circle cx="${cx}" cy="${cy}" r="${raio}" fill="#eef1f7"/><text x="${cx}" y="${cy + 5}" text-anchor="middle" font-size="14" fill="#5d6675">Sem votos</text>`;
    } else if (fatias.length === 1) {
      svg += `<circle cx="${cx}" cy="${cy}" r="${raio}" fill="${fatias[0].cor}"/>`;
    } else {
      let ang = -Math.PI / 2;
      fatias.forEach((f) => {
        const a = (f.valor / total) * Math.PI * 2;
        const x1 = cx + raio * Math.cos(ang);
        const y1 = cy + raio * Math.sin(ang);
        ang += a;
        const x2 = cx + raio * Math.cos(ang);
        const y2 = cy + raio * Math.sin(ang);
        svg += `<path d="M${cx} ${cy} L${x1.toFixed(2)} ${y1.toFixed(2)} A${raio} ${raio} 0 ${a > Math.PI ? 1 : 0} 1 ${x2.toFixed(2)} ${y2.toFixed(2)} Z" fill="${f.cor}" stroke="#fff" stroke-width="2"/>`;
      });
    }
    svg += '</svg>';
    const legenda = itens
      .map((i) => `<li><i style="background:${i.cor}"></i><span>${esc(cortar(i.rotulo, 34))} — <b>${i.valor}</b> (${pct(i.valor, total)})</span></li>`)
      .join('');
    return `<div class="pizza-wrap">${svg}<ul class="legenda">${legenda}</ul></div>`;
  }

  function renderResultados(r) {
    const simnao = r.modo === 'simnao';
    const itens = itensGrafico(r);
    const emAndamento = r.salasEncerradas < r.salasTotal;
    let faixa = '';
    let texto = '';
    if (simnao) {
      if (r.total > 0 && (r.sim > 0 || r.nao > 0)) {
        if (r.sim === r.nao) texto = 'Empate: <b>SIM</b> e <b>NÃO</b> com ' + r.sim + ' voto(s) cada.';
        else {
          const vence = r.sim > r.nao ? 'SIM' : 'NÃO';
          texto = 'Mais votos: <b>' + vence + '</b> — SIM ' + r.sim + ' (' + pct(r.sim, r.total) + ') e NÃO ' + r.nao + ' (' + pct(r.nao, r.total) + ').';
        }
      }
    } else {
      const topo = r.candidatos[0];
      if (r.total > 0 && topo && topo.votos > 0) {
        const empatados = r.candidatos.filter((c) => c.votos === topo.votos);
        texto =
          empatados.length > 1
            ? 'Empate entre ' + empatados.map((c) => esc(c.nome)).join(' e ') + ' com ' + topo.votos + ' voto(s) cada.'
            : 'Mais votado: <b>' + esc(topo.nome) + '</b> (' + esc(topo.numero) + ') com ' + topo.votos + ' voto(s) — ' + pct(topo.votos, r.total) + ' do total.';
      }
    }
    if (texto) faixa = `<div class="destaque-box ${emAndamento ? 'parcial' : ''}">${emAndamento ? '<b>Resultado parcial.</b> ' : ''}${texto}</div>`;
    let atencao = '';
    if (emAndamento && r.salasTotal) {
      atencao = `<p class="msg erro" style="font-weight:600">Atenção: ${r.salasTotal - r.salasEncerradas} de ${r.salasTotal} sala(s) ainda não foram encerradas — os números podem mudar.</p>`;
    }

    /* tabela principal */
    let tabela;
    if (simnao) {
      const lider = r.sim === r.nao ? '' : r.sim > r.nao ? 'sim' : 'nao';
      tabela = `<table class="tabela">
        <thead><tr><th>Opção</th><th class="num">Votos</th><th class="num">% do total</th></tr></thead>
        <tbody>
          <tr${lider === 'sim' ? ' class="destaque"' : ''}><td>SIM</td><td class="num">${r.sim}</td><td class="num">${pct(r.sim, r.total)}</td></tr>
          <tr${lider === 'nao' ? ' class="destaque"' : ''}><td>NÃO</td><td class="num">${r.nao}</td><td class="num">${pct(r.nao, r.total)}</td></tr>
          <tr><td>Votos em branco</td><td class="num">${r.branco}</td><td class="num">${pct(r.branco, r.total)}</td></tr>
          <tr><td>Votos nulos</td><td class="num">${r.nulo}</td><td class="num">${pct(r.nulo, r.total)}</td></tr>
          <tr class="total"><td>TOTAL</td><td class="num">${r.total}</td><td class="num">100%</td></tr>
        </tbody></table>`;
    } else {
      const linhas = r.candidatos
        .map(
          (c, i) => `<tr${i === 0 && c.votos > 0 ? ' class="destaque"' : ''}>
        <td>${i + 1}º</td><td>${esc(c.numero)}</td><td>${esc(c.nome)}</td><td>${esc(c.partido)}</td>
        <td class="num">${c.votos}</td><td class="num">${pct(c.votos, r.total)}</td></tr>`
        )
        .join('');
      tabela = `<table class="tabela">
        <thead><tr><th>Pos.</th><th>Nº</th><th>Candidato</th><th>Chapa/Turma</th><th class="num">Votos</th><th class="num">% do total</th></tr></thead>
        <tbody>${linhas || '<tr><td colspan="6" class="vazio">Nenhum candidato cadastrado.</td></tr>'}
          <tr><td></td><td></td><td>Votos em branco</td><td></td><td class="num">${r.branco}</td><td class="num">${pct(r.branco, r.total)}</td></tr>
          <tr><td></td><td></td><td>Votos nulos</td><td></td><td class="num">${r.nulo}</td><td class="num">${pct(r.nulo, r.total)}</td></tr>
          <tr class="total"><td></td><td></td><td>TOTAL</td><td></td><td class="num">${r.total}</td><td class="num">100%</td></tr>
        </tbody></table>`;
    }

    /* votação por sala */
    let matriz = '';
    if (r.porSala.length > 1 || (r.porSala.length === 1 && r.filtro === 'all')) {
      const colunas = simnao
        ? '<th class="num">Sim</th><th class="num">Não</th>'
        : r.candidatos.map((c) => `<th class="num">${esc(cortar(c.nome, 14))}<br><small>${esc(c.numero)}</small></th>`).join('');
      const corpo = r.porSala
        .map(
          (s) => `<tr><td><b>${esc(s.nome)}</b></td><td><span class="selo ${esc(s.status)}">${esc(rotuloStatus[s.status] || s.status)}</span></td>
          <td class="num">${s.votaram}/${s.alunos}</td>
          ${simnao ? `<td class="num">${s.votos.sim}</td><td class="num">${s.votos.nao}</td>` : r.candidatos.map((c) => `<td class="num">${s.votos[c.id] || 0}</td>`).join('')}
          <td class="num">${s.votos.branco}</td><td class="num">${s.votos.nulo}</td></tr>`
        )
        .join('');
      matriz = `<h2 style="margin-top:22px">Votação por sala</h2>
        <div class="tabela-wrap"><table class="tabela"><thead><tr><th>Sala</th><th>Situação</th><th class="num">Votaram</th>${colunas}<th class="num">Branco</th><th class="num">Nulo</th></tr></thead><tbody>${corpo}</tbody></table></div>`;
    }

    const cartoes = simnao
      ? `<div class="num-card"><div class="v">${r.total}</div><div class="r">votos registrados</div></div>
         <div class="num-card"><div class="v">${r.sim}</div><div class="r">votos SIM</div></div>
         <div class="num-card"><div class="v">${r.nao}</div><div class="r">votos NÃO</div></div>
         <div class="num-card"><div class="v">${r.branco}</div><div class="r">votos em branco</div></div>
         <div class="num-card"><div class="v">${r.nulo}</div><div class="r">votos nulos</div></div>
         <div class="num-card"><div class="v">${r.salasEncerradas}/${r.salasTotal}</div><div class="r">salas encerradas</div></div>`
      : `<div class="num-card"><div class="v">${r.total}</div><div class="r">votos registrados</div></div>
         <div class="num-card"><div class="v">${r.validos}</div><div class="r">votos em candidatos</div></div>
         <div class="num-card"><div class="v">${r.branco}</div><div class="r">votos em branco</div></div>
         <div class="num-card"><div class="v">${r.nulo}</div><div class="r">votos nulos</div></div>
         <div class="num-card"><div class="v">${r.salasEncerradas}/${r.salasTotal}</div><div class="r">salas encerradas</div></div>`;

    const infoChapa = simnao
      ? `<p class="muted" style="margin:0 0 14px">Chapa: <b>${esc(r.chapa ? r.chapa.nome : '—')}</b> &nbsp;•&nbsp; Pergunta: “${esc(r.pergunta)}”</p>`
      : '';

    $('#res-conteudo').innerHTML = `
      <div class="so-impressao cab-impressao">
        <img class="logo-imp" src="/logo.png" alt="">
        <h1>${esc(r.titulo)}</h1>
        <p><b>Cargo:</b> ${esc(r.cargo)} &nbsp;|&nbsp; <b>Sala:</b> ${esc(r.filtroNome)}</p>
        <p>Emitido em ${esc(r.geradoEm)}${emAndamento ? ' — <b>RESULTADO PARCIAL</b>' : ''}</p>
      </div>
      ${atencao}
      ${faixa}
      ${infoChapa}
      <div class="cards-num">${cartoes}</div>
      <h2>Resultado</h2>
      <div class="tabela-wrap">${tabela}</div>
      <div class="graficos">
        <div class="grafico-card"><h2>${simnao ? 'Votos por opção' : 'Votos por candidato'}</h2>${graficoBarras(itens, r.total)}</div>
        <div class="grafico-card"><h2>Distribuição dos votos</h2>${graficoPizza(itens, r.total)}</div>
      </div>
      ${matriz}
      <div class="so-impressao assinaturas"><div>Mesário / Responsável</div><div>Coordenação / Direção</div></div>`;
  }

  $('#res-sala').addEventListener('change', carregarResultados);
  $('#res-atualizar').addEventListener('click', carregarResultados);
  $('#res-imprimir').addEventListener('click', async () => {
    await carregarResultados();
    window.print();
  });
  $('#res-auto').addEventListener('change', () => {
    clearInterval(timerAuto);
    if ($('#res-auto').checked) timerAuto = setInterval(carregarResultados, 10000);
  });
  $('#res-csv').addEventListener('click', async () => {
    try {
      const txt = await api('GET', '/api/admin/csv?sala=' + encodeURIComponent($('#res-sala').value || 'all'), null, true);
      const blob = new Blob([txt], { type: 'text/csv;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'resultado-urna.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    } catch (err) {
      aviso(err.message, 'erro');
    }
  });

  /* ------------------------------------------------------------ */
  /* Quem votou (somente o número da chamada; nunca em quem votou)  */
  /* ------------------------------------------------------------ */
  async function carregarFrequencia() {
    try {
      const r = await api('GET', '/api/admin/frequencia');
      renderFrequencia(r);
    } catch (err) {
      $('#fq-conteudo').innerHTML = '<p class="msg erro">' + esc(err.message) + '</p>';
    }
  }

  const listaNumeros = (arr) => (arr.length ? arr.join(', ') : '—');

  function renderFrequencia(r) {
    const filtro = $('#fq-sala').value || 'all';
    const salas = filtro === 'all' ? r.salas : r.salas.filter((s) => s.id === filtro);
    if (!salas.length) {
      $('#fq-conteudo').innerHTML = '<p class="vazio">Nenhuma sala cadastrada ainda.</p>';
      return;
    }
    const nomeFiltro = filtro === 'all' ? 'Todas as salas' : salas[0].nome;
    const totalVotaram = salas.reduce((a, s) => a + s.votaram.length, 0);
    const totalAlunos = salas.reduce((a, s) => a + s.alunos, 0);

    const blocos = salas
      .map((s) => {
        const jaVotou = new Set(s.votaram);
        let celulas = '';
        for (let i = 1; i <= s.alunos; i++) {
          celulas += jaVotou.has(i)
            ? `<span class="fq-n votou" title="Nº ${i}: já votou"><b>${i}</b><i>✓</i></span>`
            : `<span class="fq-n" title="Nº ${i}: ainda não votou"><b>${i}</b></span>`;
        }
        return `<section class="fq-sala">
          <h2>${esc(s.nome)} <span class="selo ${esc(s.status)}">${esc(rotuloStatus[s.status] || s.status)}</span></h2>
          <p class="fq-resumo">Votaram <b>${s.votaram.length}</b> de <b>${s.alunos}</b> (${pct(s.votaram.length, s.alunos)}) — faltam <b>${s.faltam.length}</b></p>
          <div class="fq-grid">${celulas}</div>
          <p class="fq-lista"><b>Já votaram:</b> ${listaNumeros(s.votaram)}</p>
          <p class="fq-lista"><b>Ainda não votaram:</b> ${listaNumeros(s.faltam)}</p>
        </section>`;
      })
      .join('');

    $('#fq-conteudo').innerHTML = `
      <div class="so-impressao cab-impressao">
        <img class="logo-imp" src="/logo.png" alt="">
        <h1>${esc(r.titulo)}</h1>
        <p><b>Lista de presença na votação</b> &nbsp;|&nbsp; <b>Sala:</b> ${esc(nomeFiltro)}</p>
        <p>Emitido em ${esc(r.geradoEm)}</p>
      </div>
      <div class="cards-num">
        <div class="num-card"><div class="v">${totalVotaram}</div><div class="r">já votaram</div></div>
        <div class="num-card"><div class="v">${totalAlunos - totalVotaram}</div><div class="r">ainda não votaram</div></div>
        <div class="num-card"><div class="v">${pct(totalVotaram, totalAlunos)}</div><div class="r">de participação</div></div>
      </div>
      <p class="fq-legenda">✓ com fundo verde = já votou &nbsp;•&nbsp; sem marca = ainda não votou</p>
      ${blocos}
      <div class="so-impressao assinaturas"><div>Mesário / Responsável</div><div>Coordenação / Direção</div></div>`;
  }

  $('#fq-sala').addEventListener('change', carregarFrequencia);
  $('#fq-atualizar').addEventListener('click', carregarFrequencia);
  $('#fq-imprimir').addEventListener('click', async () => {
    await carregarFrequencia();
    window.print();
  });
  $('#fq-auto').addEventListener('change', () => {
    clearInterval(timerAuto);
    if ($('#fq-auto').checked) timerAuto = setInterval(carregarFrequencia, 10000);
  });

  /* ------------------------------------------------------------ */
  /* Configurações                                                  */
  /* ------------------------------------------------------------ */
  function aplicarModoConfig() {
    const simnao = $('#cfg-modo').value === 'simnao';
    $('#cfg-digitos-wrap').classList.toggle('oculto', simnao);
    $('#cfg-pergunta-wrap').classList.toggle('oculto', !simnao);
  }
  $('#cfg-modo').addEventListener('change', aplicarModoConfig);

  function renderConfig() {
    const c = dados.config;
    $('#cfg-titulo').value = c.titulo;
    $('#cfg-cargo').value = c.cargo;
    $('#cfg-digitos').value = String(c.digitos);
    $('#cfg-digitos').disabled = dados.candidatos.length > 0;
    $('#cfg-pin').value = c.pinMesario || '';
    $('#cfg-modo').value = c.modo || 'candidatos';
    const travado = dados.candidatos.length > 0 || dados.temVotos;
    $('#cfg-modo').disabled = travado;
    $('#cfg-modo-dica').textContent = travado
      ? ' Para mudar o tipo de votação, exclua os candidatos/chapas cadastrados (e zere a votação, se já houver votos).'
      : '';
    $('#cfg-pergunta').value = c.pergunta || '';
    aplicarModoConfig();
    const ends = dados.enderecos.length ? dados.enderecos : [];
    $('#enderecos').innerHTML =
      '<li>Neste computador: <b>' + esc(location.origin) + '/urna</b> e <b>' + esc(location.origin) + '/admin</b></li>' +
      ends.map((e) => `<li>Na rede: <b>${esc(e)}/urna</b> &nbsp;|&nbsp; <b>${esc(e)}/admin</b></li>`).join('');
  }

  $('#form-config').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#cfg-msg').textContent = '';
    try {
      await api('PUT', '/api/admin/config', {
        titulo: $('#cfg-titulo').value,
        cargo: $('#cfg-cargo').value,
        digitos: $('#cfg-digitos').value,
        modo: $('#cfg-modo').value,
        pergunta: $('#cfg-pergunta').value,
        pinMesario: $('#cfg-pin').value
      });
      aviso('Configurações salvas.');
      await recarregar();
    } catch (err) {
      $('#cfg-msg').textContent = err.message;
    }
  });

  $('#form-senha').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#sn-msg').textContent = '';
    try {
      await api('POST', '/api/admin/senha', { atual: $('#sn-atual').value, nova: $('#sn-nova').value });
      $('#form-senha').reset();
      aviso('Senha alterada com sucesso.');
      await recarregar();
    } catch (err) {
      $('#sn-msg').textContent = err.message;
    }
  });

  $('#form-zerar').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#zr-msg').textContent = '';
    if ($('#zr-texto').value.trim() !== 'ZERAR') {
      $('#zr-msg').textContent = 'Digite ZERAR (em maiúsculas) para confirmar.';
      return;
    }
    if (!confirm('Tem certeza? Todos os votos serão apagados.')) return;
    try {
      await api('POST', '/api/admin/zerar', { confirmacao: 'ZERAR' });
      $('#form-zerar').reset();
      aviso('Votação zerada.');
      await recarregar();
    } catch (err) {
      $('#zr-msg').textContent = err.message;
    }
  });

  /* ------------------------------------------------------------ */
  /* Início                                                         */
  /* ------------------------------------------------------------ */
  if (token) {
    entrar().catch(() => sair(false));
  } else {
    $('#login-senha').focus();
  }
})();
